const toggle = document.getElementById("toggle");
const sites = document.getElementById("sites");
const save = document.getElementById("save");

async function load(){
  const data = await chrome.storage.local.get(["enabled", "blockedSites"]);
  const enabled = Boolean(data.enabled);
  toggle.textContent = enabled ? "Focus Mode ON" : "Focus Mode OFF";
  toggle.classList.toggle("off", !enabled);
  sites.value = (data.blockedSites || []).join("\n");
}

toggle.addEventListener("click", async () => {
  const data = await chrome.storage.local.get("enabled");
  await chrome.storage.local.set({ enabled: !data.enabled });
  load();
});

save.addEventListener("click", async () => {
  const blockedSites = sites.value.split("\n").map(s => s.trim()).filter(Boolean);
  await chrome.storage.local.set({ blockedSites });
  save.textContent = "Saved";
  setTimeout(()=> save.textContent = "Save Block List", 900);
});

load();
