const params = new URLSearchParams(location.search);
const site = params.get("site");
if (site) document.getElementById("siteText").textContent = `${site} is blocked during Focus Mode.`;
document.getElementById("back").addEventListener("click", () => history.back());
