const DEFAULT_BLOCKED = [
  "instagram.com",
  "facebook.com",
  "x.com",
  "twitter.com",
  "reddit.com",
  "youtube.com",
  "tiktok.com",
  "snapchat.com"
];

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get(["enabled", "blockedSites"]);
  if (!existing.blockedSites) {
    await chrome.storage.local.set({ enabled: false, blockedSites: DEFAULT_BLOCKED });
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "loading" || !tab.url) return;

  const { enabled, blockedSites } = await chrome.storage.local.get(["enabled", "blockedSites"]);
  if (!enabled) return;

  let url;
  try {
    url = new URL(tab.url);
  } catch {
    return;
  }

  const hostname = url.hostname.replace(/^www\./, "").toLowerCase();
  const shouldBlock = (blockedSites || DEFAULT_BLOCKED).some(site => {
    const clean = site.replace(/^www\./, "").toLowerCase().trim();
    return clean && (hostname === clean || hostname.endsWith("." + clean));
  });

  if (shouldBlock && !tab.url.includes("blocked.html")) {
    const redirectUrl = chrome.runtime.getURL(`blocked.html?site=${encodeURIComponent(hostname)}`);
    chrome.tabs.update(tabId, { url: redirectUrl });
  }
});
